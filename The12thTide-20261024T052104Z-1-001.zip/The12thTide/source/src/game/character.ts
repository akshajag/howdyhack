import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { patchMaterial } from '../core/env';
import { loadMesh } from '../core/assets';
import { MOVE } from './types';
import type { Runner } from './runner';

/**
 * The runner's body: Quaternius' CC0 "Beach Character" (poly.pizza/m/DojKLcO34E) with its hand-animated clips
 * (Idle, Run, Roll, Hit, Death, Wave) plus Jump and Swim keyed on the same rig (blender/runner/author_q_clips.py).
 * Clips are cross-faded with three.js' AnimationMixer, as in the official skinning-blending example; the code only
 * picks the clip, its playback speed, and the body's lean / prone pitch.
 */
type ClipName = 'Idle' | 'Run' | 'Roll' | 'Hit' | 'Death' | 'Wave' | 'Jump' | 'Swim';
const HEIGHT = 1.75;
const HIP = 0.9;
/** where the dive pack sits (model space at load: centre height, distance behind the body's centre line) */
const PACK_AT = [0, 1.2, 0.1];            // pivot height for leaning and the prone swim pitch

export class Character {
  readonly root = new THREE.Group();          // placed at the runner's feet, facing -z
  private body = new THREE.Group();            // lean / prone pitch, pivoting at the hips
  private model = new THREE.Group();
  private mixer: THREE.AnimationMixer | null = null;
  private actions = new Map<ClipName, THREE.AnimationAction>();
  private current: ClipName | null = null;
  private swimBlend = 0;
  private hitT = 0;
  private lastStumble = 0;
  private wasAir = false;
  private wasSlide = false;
  private dead = false;
  loaded = false;
  ready: Promise<void>;
  private fallback: THREE.Mesh | null = null;

  constructor() {
    this.root.add(this.body);
    this.body.position.y = HIP;
    this.body.add(this.model);
    this.model.position.y = -HIP;
    this.ready = this.load();
  }

  private async load() {
    try {
      const gltf = await new GLTFLoader().loadAsync('runner/models/Runner_Beach.glb');
      const scene = gltf.scene;
      scene.traverse((o) => {
        const m = o as THREE.SkinnedMesh;
        if (!m.isMesh) return;
        m.castShadow = true; m.receiveShadow = false; m.frustumCulled = false;
        const mats = Array.isArray(m.material) ? m.material : [m.material];
        for (const mat of mats) {
          // the source materials are 40% metallic, which renders near-black without an environment map
          const sm = mat as THREE.MeshStandardMaterial;
          sm.metalness = 0; sm.roughness = 0.7;
          // Aggie touches: the tank top becomes a dark wetsuit top, the trunks true maroon
          if (sm.name.startsWith('LightBrown')) sm.color.setHex(0x26303a);
          if (sm.name.startsWith('Red_Dark')) sm.color.setHex(0x500000);
          patchMaterial(sm, { caustics: true });
        }
      });
      // normalise: 1.75 m tall, feet on the ground, facing -z (the source faces +z)
      scene.updateMatrixWorld(true);
      const box = new THREE.Box3().setFromObject(scene, true);
      const s = HEIGHT / Math.max(0.01, box.max.y - box.min.y);
      scene.scale.setScalar(s);
      scene.position.y = -box.min.y * s;
      scene.rotation.y = Math.PI;
      this.model.add(scene);
      // a small dive pack with a white 12 on the runner's back, carried by the chest bone
      const chest = scene.getObjectByName('Chest');
      if (chest) {
        const packSrc = await loadMesh('runner/models/Runner_Pack.glb');
        const pack = new THREE.Mesh(packSrc.geometry, patchMaterial(new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.75 }), { caustics: true }));
        pack.castShadow = true;
        pack.position.set(0, PACK_AT[1], PACK_AT[2]);           // the runner faces -z, so its back (and the pack's outer face) is +z
        this.model.add(pack);
        this.model.updateMatrixWorld(true);
        chest.attach(pack);
      }
      this.mixer = new THREE.AnimationMixer(scene);
      for (const clip of gltf.animations) {
        const a = this.mixer.clipAction(clip);
        if (['Jump', 'Roll', 'Hit', 'Death'].includes(clip.name)) { a.setLoop(THREE.LoopOnce, 1); a.clampWhenFinished = true; }
        this.actions.set(clip.name as ClipName, a);
      }
      this.play('Idle', 0);
      this.loaded = true;
    } catch (e) {
      console.warn('character failed to load, using a capsule:', (e as Error).message);
      const geo = new THREE.CapsuleGeometry(0.32, 1.1, 6, 12);
      geo.translate(0, 0.87, 0);
      this.fallback = new THREE.Mesh(geo, patchMaterial(new THREE.MeshStandardMaterial({ color: new THREE.Color('#f2ece2'), roughness: 0.6 })));
      this.fallback.castShadow = true;
      this.model.add(this.fallback);
    }
  }

  /** cross-fade to a clip; one-shot clips restart from the beginning */
  private play(name: ClipName, fade = 0.15, restart = false) {
    const next = this.actions.get(name);
    if (!next) return;
    if (this.current === name && !restart) return;
    const prev = this.current ? this.actions.get(this.current) : null;
    next.reset();
    next.enabled = true;
    next.setEffectiveWeight(1);
    next.play();
    if (prev && prev !== next && fade > 0) prev.crossFadeTo(next, fade, false);
    else if (prev && prev !== next) prev.stop();
    this.current = name;
  }

  private speed(name: ClipName, ts: number) { const a = this.actions.get(name); if (a) a.timeScale = ts; }

  /** dev: hold a clip at a fixed phase (?pose=run|jump|roll|swim|hit|death|idle) */
  debugPose(name: string, _t: number, _r: Runner, phase = 0.4) {
    const clip = (name.charAt(0).toUpperCase() + name.slice(1)) as ClipName;
    const a = this.actions.get(clip);
    if (!a || !this.mixer) return;
    if (this.current !== clip) { this.mixer.stopAllAction(); a.reset().play(); this.current = clip; }
    a.paused = true;
    a.time = a.getClip().duration * phase;
    this.mixer.update(0);
    this.body.rotation.set(clip === 'Swim' ? -(Math.PI / 2 - 0.15) : 0, 0, 0, 'YXZ');
  }

  update(dt: number, _t: number, r: Runner, idle = false) {
    const swim = r.mode === 'swim' && !idle;
    this.swimBlend += ((swim ? 1 : 0) - this.swimBlend) * (1 - Math.exp(-dt * 7));
    const sb = this.swimBlend;
    // swimming: runner.pos is the hip position; on land it is the feet
    this.root.position.set(r.pos.x, r.pos.y - HIP * sb, r.pos.z);
    // lean into a lane change: the body turns a little toward it and banks, both eased (lean is already smoothed)
    const yaw = -r.lean * 0.26 * (1 - sb * 0.4);
    const bank = -r.lean * (0.14 + 0.22 * sb);
    const pitch = -sb * (Math.PI / 2 - 0.15 - THREE.MathUtils.clamp(r.vy * 0.12, -0.45, 0.45));
    this.body.rotation.set(idle ? 0 : pitch, idle ? 0 : yaw, idle ? 0 : bank, 'YXZ');
    if (this.fallback) this.fallback.scale.y = r.sliding > 0 && !idle ? 0.5 : 1;

    // ---------------- clip selection
    if (idle) { this.dead = false; this.play('Idle'); }
    else if (!r.alive) { if (!this.dead) { this.dead = true; this.play('Death', 0.1, true); } }
    else {
      this.dead = false;
      if (r.stumble > this.lastStumble + 0.5) this.hitT = 0.45;          // a fresh hit: stumble through the Hit clip
      this.hitT = Math.max(0, this.hitT - dt);
      const slideStart = r.sliding > 0 && !this.wasSlide;
      const jumpStart = r.airborne && !this.wasAir && r.vy > 0;
      if (swim) {
        this.play('Swim', 0.3);
        this.speed('Swim', THREE.MathUtils.clamp(r.speed / 11, 0.8, 1.8) * (r.surgeT > 0 ? 1.4 : 1));
      } else if (this.hitT > 0 && !r.airborne && r.sliding <= 0) {
        this.play('Hit', 0.08, this.hitT >= 0.44); this.speed('Hit', 1.2);
      } else if (r.sliding > 0) {
        if (slideStart || this.current !== 'Roll') this.play('Roll', 0.08, true);
        this.speed('Roll', 1.333 / (MOVE.slideTime + 0.15));
      } else if (r.airborne) {
        // a real jump plays Jump timed to the airtime; dropping off a ledge keeps the current pose
        if (jumpStart) this.play('Jump', 0.06, true);
        this.speed('Jump', 0.833 / MOVE.jumpTime);
      } else {
        this.play('Run', this.current === 'Jump' ? 0.1 : 0.2);
        this.speed('Run', THREE.MathUtils.clamp(r.speed / 12, 0.85, 1.7) * (r.mode === 'surf' ? 0.85 : 1));
      }
      this.wasSlide = r.sliding > 0; this.wasAir = r.airborne;
    }
    this.lastStumble = r.stumble;
    this.mixer?.update(dt);
  }
}
