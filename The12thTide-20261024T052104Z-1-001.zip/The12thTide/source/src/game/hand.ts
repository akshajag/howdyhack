import type { InputState } from './input';

/**
 * Webcam hand controller (MediaPipe Hand Landmarker). Either hand, mirrored preview. Distances are in palm lengths
 * (wrist to the middle knuckle, measured at calibration, x corrected for the frame's aspect), so it feels the same
 * near or far from the camera and the same across and up / down.
 *  - on land: left / centre / right zones pick the lane (hysteresis). Jump / slide: a quick flick up / down (mostly
 *    vertical), or a slow raise / drop well away from rest. Rest is a slow baseline that follows an arm that sinks
 *    or rises over a run. After a jump the slide is locked out for a moment (the hand coming back down mustn't slam you
 *    out of the air), and the other way round; neither fires just after a lane change or after the hand comes back
 *  - under water: the hand is where you swim to (position control: across the canyon and up / down)
 *  - closed fist (edge, debounced) = surge
 * Inference runs in a Web Worker on transferred ImageBitmaps (new frames only, capped at ~30 Hz); falls back to the
 * main thread if workers / OffscreenCanvas are unavailable. Losing the hand keeps the lane / course; a long loss pauses.
 * Tuned from mid-air input guidance (Meta hand-gesture design, Ultraleap XR guidelines, the One Euro filter paper,
 * elbow-anchored interaction).
 */
export const HAND_SETTINGS = {
  sensitivity: 1.0,     // higher = less movement needed (divides every distance below)
  laneEnter: 0.55,      // palm lengths from rest to pick a side lane...
  laneLeave: 0.3,       // ...and back inside this to return to the middle
  swimX: 1.2,           // palm lengths for the full width of the canyon under water
  swimY: 1.0,           // palm lengths for seabed to surface
  flickDist: 0.5,       // palm lengths up / down within flickWindow = jump / slide
  flickWindow: 0.2,     // s
  holdDist: 0.85,       // or just raise / lower the hand this far from rest
  flickEnd: 0.25,       // a flick only counts if it ends this far past rest (the hand returning to rest isn't one)
  rearm: 0.3,           // back within this of rest, and still, re-arms the gesture
  refractory: 0.4,      // s after a jump before a slide can fire, and the other way round
  laneQuiet: 0.15,      // s after a lane change with no jump / slide
  fistIn: 1.1, fistOut: 1.35,   // fingertip reach / palm length: a fist below fistIn (3 frames running), open above fistOut
  lossGrace: 0.35,      // s without a hand before tracking counts as lost (a dropped frame or two is ignored)
  reacquireQuiet: 0.3,  // s of no gestures after the hand comes back (the filters restart)
  lostPauseAfter: 1.5,  // s lost before the run pauses
  resumeAfter: 0.6,     // s of steady tracking before a paused run goes again
};

export type HandStatus = 'off' | 'loading' | 'calibrating' | 'tracking' | 'lost' | 'error';
type P = [number, number, number];

const MP_BASE = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@1.0.1';
const MODEL = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';
/**
 * Hand-tracking worker source (MediaPipe tasks-vision 1.0.1, Apache-2.0, loaded from the CDN at runtime, not bundled).
 * The page posts ImageBitmaps; the worker answers with palm landmarks and the handedness score.
 */
const WORKER_SRC = `
importScripts('${MP_BASE}/vision_bundle.js');
let landmarker = null, busy = false;
self.onmessage = async (ev) => {
  const msg = ev.data;
  if (msg.type === 'init') {
    try {
      const files = await Vision.FilesetResolver.forVisionTasks('${MP_BASE}/wasm');
      const make = (delegate) => Vision.HandLandmarker.createFromOptions(files, {
        baseOptions: { modelAssetPath: '${MODEL}', delegate }, runningMode: 'VIDEO', numHands: 2,
        minHandDetectionConfidence: 0.55, minHandPresenceConfidence: 0.55, minTrackingConfidence: 0.5 });
      try { landmarker = await make('GPU'); } catch (e) { landmarker = await make('CPU'); }
      postMessage({ type: 'ready' });
    } catch (e) { postMessage({ type: 'error', error: String((e && e.message) || e) }); }
  } else if (msg.type === 'frame') {
    const bmp = msg.bitmap;
    if (!landmarker || busy) { bmp.close(); postMessage({ type: 'drop', t: msg.t }); return; }
    busy = true;
    try {
      const res = landmarker.detectForVideo(bmp, msg.t);
      const hands = (res.landmarks || []).map((lm) => lm.map((p) => [p.x, p.y, p.z]));
      const names = (res.handedness || []).map((h) => (h && h[0] ? h[0].categoryName : ''));
      postMessage({ type: 'result', t: msg.t, hands, names });
    } catch (e) { postMessage({ type: 'result', t: msg.t, hands: [], names: [], error: String(e) }); }
    finally { bmp.close(); busy = false; }
  }
};`;

export class HandTracker {
  status: HandStatus = 'off';
  error = '';
  /** which hand MediaPipe thinks it sees ('Left' / 'Right' in image space) */
  hand = '';
  /** raw palm centre in image space (0..1), for the preview */
  raw: { x: number; y: number } | null = null;
  neutral: { x: number; y: number } | null = null;
  private calib: { x: number; y: number }[] = [];
  private calibT = 0;
  private video: HTMLVideoElement | null = null;
  private stream: MediaStream | null = null;
  private worker: Worker | null = null;
  private mainThread: { detectForVideo: (v: HTMLVideoElement, t: number) => { landmarks: { x: number; y: number; z: number }[][]; handedness: { score: number; categoryName: string }[][] } } | null = null;
  /** every hand seen this frame (the one nearest the last is followed) */
  private hands: P[][] = []; private names: string[] = [];
  private pending = false;
  private lastVideoTime = -1;
  private lastSent = 0;
  private lastSeen = -1;
  private lastT = 0;
  private sx = 0; private sy = 0;          // hand offset from rest, in palm lengths (+ = your right / up)
  // One Euro filters on the palm position (aspect-corrected frame-height units): steady when still, quick when moving.
  // beta is in those units (a fast hand moves ~1-3 units / s), so it's large; the paper's tuning order: minCutoff for
  // a still hand, then beta until fast moves stop lagging
  private fx = new OneEuro(1.0, 12); private fy = new OneEuro(1.0, 12);
  private palm = 0.14;                     // palm length at calibration (frame-height units)
  private calibPalm: number[] = [];
  private hist: { t: number; x: number; y: number }[] = [];   // recent offsets, per camera frame
  private base = 0;                        // slow rest height (palm lengths) the gestures are measured from
  private zone = 0;                        // -1 / 0 / 1 lane zone
  private laneT = -9; private quietUntil = 0; private noJumpUntil = 0; private noSlideUntil = 0;
  private jumpArmed = true; private slideArmed = true;
  private pendJump = false; private pendSlide = false; private pendSurge = false;
  private fistCount = 0;
  private landmarks: P[] | null = null;
  /** seconds of continuous tracking since the hand was last lost (the game resumes once it's steady) */
  steadyFor = 0;
  /** the last gesture and when (for the HUD flash) */
  gesture: { kind: 'jump' | 'slide' | 'surge'; t: number } | null = null;
  /** setup advice while calibrating ('' when fine) */
  hint = '';
  private frameFresh = false;
  /** true after a long tracking loss: the game should pause */
  lostLong = false;
  lostFor = 0;
  fist = false;
  inferenceMs = 0;
  usingWorker = false;
  framesIn = 0; framesDone = 0;
  /** test hook: feed synthetic landmarks instead of the camera */
  simulated = false;

  async start(): Promise<boolean> {
    if (this.status !== 'off' && this.status !== 'error') return true;
    this.status = 'loading'; this.error = '';
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error(window.isSecureContext ? 'this browser has no camera access' : 'the camera only works over https:// or on localhost');
      this.stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480, facingMode: 'user', frameRate: { ideal: 30 } }, audio: false });
      const v = document.createElement('video');
      v.srcObject = this.stream; v.muted = true; v.playsInline = true;
      await v.play();
      this.video = v;
      await this.initInference();
      this.status = 'calibrating';
      this.recalibrate();
      return true;
    } catch (e) {
      this.status = 'error'; this.error = (e as Error).message ?? String(e);
      this.stop(false);
      return false;
    }
  }

  private async initInference() {
    const canWorker = typeof Worker !== 'undefined' && typeof createImageBitmap !== 'undefined' && typeof OffscreenCanvas !== 'undefined';
    if (canWorker) {
      try {
        // classic (importScripts) worker from a Blob: MediaPipe's wasm loader needs importScripts, which module workers lack
        const w = new Worker(URL.createObjectURL(new Blob([WORKER_SRC], { type: 'text/javascript' })));
        await new Promise<void>((res, rej) => {
          const timer = setTimeout(() => rej(new Error('hand worker timed out')), 45000);
          w.onmessage = (ev) => {
            const m = ev.data;
            if (m.type === 'ready') { clearTimeout(timer); res(); }
            else if (m.type === 'error') { clearTimeout(timer); rej(new Error(m.error)); }
          };
          w.onerror = (e) => { clearTimeout(timer); rej(new Error(e.message || 'worker error')); };
          w.postMessage({ type: 'init' });
        });
        w.onmessage = (ev) => this.onWorkerResult(ev.data);
        this.worker = w; this.usingWorker = true;
        return;
      } catch (e) {
        console.warn('hand worker unavailable, falling back to the main thread:', (e as Error).message);
      }
    }
    const vision = await import(/* @vite-ignore */ `${MP_BASE}/vision_bundle.mjs`);
    const files = await vision.FilesetResolver.forVisionTasks(`${MP_BASE}/wasm`);
    this.mainThread = await vision.HandLandmarker.createFromOptions(files, {
      baseOptions: { modelAssetPath: MODEL, delegate: 'GPU' },
      runningMode: 'VIDEO', numHands: 1, minHandDetectionConfidence: 0.55, minHandPresenceConfidence: 0.55, minTrackingConfidence: 0.5,
    });
  }

  stop(resetStatus = true) {
    this.worker?.terminate(); this.worker = null;
    this.stream?.getTracks().forEach((t) => t.stop()); this.stream = null;
    this.video = null; this.mainThread = null; this.pending = false;
    if (resetStatus) this.status = 'off';
  }

  recalibrate() { this.neutral = null; this.calib = []; this.calibPalm = []; this.calibT = 0; this.fx.reset(); this.fy.reset(); this.hist = []; this.base = 0; if (this.status === 'tracking' || this.status === 'lost') this.status = 'calibrating'; }

  private onWorkerResult(m: { type: string; t: number; hands: P[][]; names: string[] }) {
    if (m.type === 'drop') { this.pending = false; return; }
    if (m.type !== 'result') return;
    this.pending = false;
    this.framesDone++;
    this.inferenceMs = performance.now() - m.t;
    this.hands = m.hands ?? []; this.names = m.names ?? [];
    this.frameFresh = true;
  }

  /** of the hands in view, the one nearest the hand we were following (another person's hand doesn't take over) */
  private pickHand(): P[] | null {
    if (!this.hands.length) return null;
    if (this.hands.length === 1 || !this.raw) { this.hand = this.names[0] ?? ''; return this.hands[0]; }
    let best = 0, bd = Infinity;
    this.hands.forEach((lm, i) => { const d = Math.hypot(lm[9][0] - this.raw!.x, lm[9][1] - this.raw!.y); if (d < bd) { bd = d; best = i; } });
    this.hand = this.names[best] ?? '';
    return this.hands[best];
  }

  /** pump a camera frame to the worker (new frames only, ~30 Hz max) */
  private pump(now: number) {
    const v = this.video;
    if (!v || v.readyState < 2 || this.simulated) return;
    if (v.currentTime === this.lastVideoTime) return;
    if (this.worker) {
      if (this.pending || now - this.lastSent < 0.03) return;
      this.lastVideoTime = v.currentTime; this.lastSent = now; this.pending = true; this.framesIn++;
      createImageBitmap(v).then((bmp) => this.worker?.postMessage({ type: 'frame', bitmap: bmp, t: performance.now() }, [bmp])).catch(() => { this.pending = false; });
    } else if (this.mainThread) {
      this.lastVideoTime = v.currentTime; this.framesIn++;
      const t0 = performance.now();
      try {
        const res = this.mainThread.detectForVideo(v, t0);
        this.hands = (res.landmarks ?? []).map((lm) => lm.map((p) => [p.x, p.y, p.z] as P));
        this.names = (res.handedness ?? []).map((h) => h?.[0]?.categoryName ?? '');
      } catch { this.hands = []; }
      this.inferenceMs = performance.now() - t0; this.framesDone++;
      this.frameFresh = true;
    }
  }

  /** test hook: inject landmarks for this frame (null = no hand) */
  feed(landmarks: P[] | null) { this.hands = landmarks ? [landmarks] : []; this.names = ['']; this.frameFresh = true; this.simulated = true; if (this.status === 'off') this.status = 'calibrating'; }

  /** Call once per frame. Writes into inp; returns true when a hand drives the input. */
  update(now: number, inp: InputState, underwater: boolean): boolean {
    const dt = Math.min(0.1, Math.max(0, now - this.lastT)); this.lastT = now;
    if (this.status === 'off' || this.status === 'loading' || this.status === 'error') return false;
    this.pump(now);
    const S = HAND_SETTINGS;
    const fresh = this.frameFresh; this.frameFresh = false;
    const lm = fresh ? this.pickHand() : null;
    if (fresh) this.landmarks = lm;
    if (fresh && lm && lm.length >= 21) {
      // back after a real gap: restart the filters and the gesture history, and hold gestures for a moment (the jump
      // from where the hand was to where it is must not read as a flick)
      if (this.lastSeen < 0 || now - this.lastSeen > S.lossGrace) { this.fx.reset(); this.fy.reset(); this.hist = []; this.quietUntil = now + S.reacquireQuiet; this.steadyFor = 0; }
      this.steadyFor += this.lastSeen >= 0 ? Math.min(0.1, now - this.lastSeen) : 0;
      this.lastSeen = now; this.lostFor = 0; this.lostLong = false;
      const asp = this.video && this.video.videoHeight ? this.video.videoWidth / this.video.videoHeight : 4 / 3;
      const idx = [0, 5, 9, 13, 17];
      const px = idx.reduce((a, i) => a + lm[i][0], 0) / 5, py = idx.reduce((a, i) => a + lm[i][1], 0) / 5;
      const cx = this.fx.filter(px * asp, now), cy = this.fy.filter(py, now);
      this.raw = { x: cx / asp, y: cy };
      const size = Math.hypot((lm[9][0] - lm[0][0]) * asp, lm[9][1] - lm[0][1]) || 0.1;
      if (!this.neutral) {
        // calibration: ~0.6 s of a still hand, near the middle of the picture, not too near or far
        this.hint = px < 0.22 || px > 0.78 || py < 0.18 || py > 0.78 ? 'move your hand toward the middle of the picture'
          : size < 0.08 ? 'come a little closer to the camera' : size > 0.32 ? 'move back a little from the camera' : '';
        if (this.hint) { this.calib = []; this.calibPalm = []; this.calibT = 0; }
        else {
          this.calib.push({ x: cx, y: cy }); this.calibPalm.push(size); this.calibT += dt;
          const mx = this.calib.reduce((a, c) => a + c.x, 0) / this.calib.length, my = this.calib.reduce((a, c) => a + c.y, 0) / this.calib.length;
          const spread = Math.max(...this.calib.map((c) => Math.hypot(c.x - mx, c.y - my)));
          if (spread > 0.06) { this.calib = [{ x: cx, y: cy }]; this.calibPalm = [size]; this.calibT = 0; }
          if (this.calib.length >= 10 && this.calibT >= 0.6) {
            this.neutral = { x: mx, y: my };
            this.palm = [...this.calibPalm].sort((a, b) => a - b)[this.calibPalm.length >> 1];
            this.base = 0; this.hist = []; this.zone = 0;
          }
        }
        this.status = 'calibrating';
        inp.present = true; inp.source = 'hand';
        return true;
      }
      this.status = 'tracking'; this.hint = '';
      const U = this.palm / S.sensitivity;
      // the camera image is not mirrored: moving your hand to YOUR right lowers image x
      const dx = -(cx - this.neutral.x) / U, dy = -(cy - this.neutral.y) / U;
      this.sx = dx; this.sy = dy;
      this.hist.push({ t: now, x: dx, y: dy });
      while (this.hist.length > 2 && now - this.hist[0].t > S.flickWindow + 0.1) this.hist.shift();
      // lane zone with hysteresis (a lane change briefly blocks jump / slide)
      const z0 = this.zone;
      if (dx > S.laneEnter) this.zone = 1; else if (dx < -S.laneEnter) this.zone = -1;
      else if ((this.zone === 1 && dx < S.laneLeave) || (this.zone === -1 && dx > -S.laneLeave)) this.zone = 0;
      if (this.zone !== z0) this.laneT = now;
      // gestures, measured per camera frame: a quick flick (mostly vertical) or a slow move well away from rest
      if (!underwater) {
        const old = this.hist.find((h) => now - h.t <= S.flickWindow) ?? this.hist[0];
        const ddy = dy - old.y, ddx = Math.abs(dx - old.x), rel = dy - this.base;
        const quiet = now < this.quietUntil || now - this.laneT < S.laneQuiet;
        if (!quiet && this.jumpArmed && now > this.noJumpUntil && ((ddy > S.flickDist && ddy > 2 * ddx && rel > S.flickEnd) || rel > S.holdDist)) {
          this.pendJump = true; this.jumpArmed = false; this.noSlideUntil = now + S.refractory; this.gesture = { kind: 'jump', t: now };
        }
        if (!quiet && this.slideArmed && now > this.noSlideUntil && ((-ddy > S.flickDist && -ddy > 2 * ddx && rel < -S.flickEnd) || rel < -S.holdDist)) {
          this.pendSlide = true; this.slideArmed = false; this.noJumpUntil = now + S.refractory; this.gesture = { kind: 'slide', t: now };
        }
        const still = Math.abs(ddy) < 0.2;
        if (still && rel < S.rearm) this.jumpArmed = true;
        if (still && rel > -S.rearm) this.slideArmed = true;
        // rest follows a slowly sinking or rising arm, but only while the hand is calm and near it
        if (Math.abs(rel) < 0.35 && Math.abs(ddy) < 0.15) this.base += (dy - this.base) * Math.min(1, dt / 1.5);
      }
      // fist: closed below fistIn for 3 frames running (not mid-flick, when the fingers blur), open again above fistOut
      const tips = [8, 12, 16, 20].reduce((a, i) => a + Math.hypot((lm[i][0] - lm[0][0]) * asp, lm[i][1] - lm[0][1]), 0) / 4 / size;
      const old = this.hist[0], fast = old && now > old.t ? Math.hypot(dx - old.x, dy - old.y) / (now - old.t) > 3 : false;
      this.fistCount = tips < S.fistIn && !fast ? this.fistCount + 1 : 0;
      if (!this.fist && this.fistCount >= 3) { this.fist = true; this.pendSurge = true; this.gesture = { kind: 'surge', t: now }; }
      else if (this.fist && tips > S.fistOut) this.fist = false;
    }
    // tracking loss: after a real gap. On foot you keep your lane, under water your course; a long loss pauses the run
    if (this.lastSeen >= 0 && now - this.lastSeen > S.lossGrace) {
      this.lostFor = now - this.lastSeen; this.steadyFor = 0;
      if (this.lostFor > S.lostPauseAfter) this.lostLong = true;
      this.fist = false; this.fistCount = 0;
      if (this.neutral) this.status = 'lost';
    }
    if (this.status !== 'tracking' && this.status !== 'lost') return false;
    inp.present = true; inp.source = 'hand';
    if (underwater) {
      inp.aim = { x: Math.max(-1, Math.min(1, this.sx / S.swimX)), y: Math.max(-1, Math.min(1, this.sy / S.swimY)) };
      inp.steer = inp.aim.x; inp.vert = inp.aim.y;
      this.pendJump = this.pendSlide = false;
    } else {
      inp.steer = this.zone;
      if (this.pendJump) inp.jump = true;
      if (this.pendSlide) inp.slide = true;
      inp.slideHeld = this.status === 'tracking' && this.sy - this.base < -S.holdDist * 0.6;
      this.pendJump = this.pendSlide = false;
    }
    if (this.pendSurge) { inp.surge = true; this.pendSurge = false; }
    return true;
  }

  /** the hand's offset from rest in palm lengths (+ = your right / up), for on-screen feedback */
  get stick() { return { x: this.sx, y: this.sy }; }
  /** seconds since the last gesture registered */
  get gestureAge() { return this.gesture ? this.lastT - this.gesture.t : Infinity; }

  /** draw the mirrored preview with the neutral box and the palm marker */
  drawPreview(c: HTMLCanvasElement) {
    const g = c.getContext('2d')!;
    g.clearRect(0, 0, c.width, c.height);
    g.save(); g.translate(c.width, 0); g.scale(-1, 1);
    if (this.video && this.video.readyState >= 2) g.drawImage(this.video, 0, 0, c.width, c.height);
    else { g.fillStyle = '#0a1a28'; g.fillRect(0, 0, c.width, c.height); }
    if (this.neutral) {
      // rest, the lane zone edges and the jump / slide lines, in palm lengths (x corrected for the frame's aspect)
      const asp = this.video && this.video.videoHeight ? this.video.videoWidth / this.video.videoHeight : 4 / 3;
      const U = this.palm / HAND_SETTINGS.sensitivity, nx = (this.neutral.x / asp) * c.width, ny = this.neutral.y * c.height;
      const ux = (U / asp) * c.width, uy = U * c.height, S = HAND_SETTINGS;
      g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 1.5; g.setLineDash([4, 4]);
      for (const k of [-S.laneEnter, S.laneEnter]) { g.beginPath(); g.moveTo(nx + k * ux, 0); g.lineTo(nx + k * ux, c.height); g.stroke(); }
      g.setLineDash([]);
      g.strokeStyle = 'rgba(255,210,122,.6)';
      for (const k of [S.holdDist, -S.holdDist]) { const y = ny - (this.base + k) * uy; g.beginPath(); g.moveTo(nx - 1.4 * ux, y); g.lineTo(nx + 1.4 * ux, y); g.stroke(); }
      g.strokeStyle = 'rgba(127,247,238,.6)'; g.beginPath(); g.arc(nx, ny - this.base * uy, 5, 0, Math.PI * 2); g.stroke();
    }
    if (this.landmarks && this.status !== 'lost') {
      g.fillStyle = 'rgba(127,247,238,.9)';
      for (const p of this.landmarks) { g.beginPath(); g.arc(p[0] * c.width, p[1] * c.height, 2, 0, Math.PI * 2); g.fill(); }
    }
    if (this.raw && this.status === 'tracking') {
      g.fillStyle = this.fist ? '#ffb347' : '#7ff7ee';
      g.beginPath(); g.arc(this.raw.x * c.width, this.raw.y * c.height, 7, 0, Math.PI * 2); g.fill();
    }
    g.restore();
    if (this.status === 'lost') { g.fillStyle = 'rgba(255,120,100,.25)'; g.fillRect(0, 0, c.width, c.height); }
  }
}

/** One Euro filter (Casiez, Roussel and Vogel, CHI 2012): a low-pass whose cutoff rises with speed, so a still hand
 *  doesn't jitter and a moving one doesn't lag. Hand-written from the paper's formulas. */
class OneEuro {
  private x: number | null = null; private dx = 0; private t = 0;
  constructor(private minCutoff: number, private beta: number, private dCutoff = 1.0) {}
  reset() { this.x = null; this.dx = 0; }
  private static alpha(cutoff: number, dt: number) { const tau = 1 / (2 * Math.PI * cutoff); return 1 / (1 + tau / dt); }
  filter(v: number, t: number) {
    if (this.x === null) { this.x = v; this.t = t; return v; }
    const dt = Math.max(1e-3, t - this.t); this.t = t;
    const d = (v - this.x) / dt;
    this.dx += OneEuro.alpha(this.dCutoff, dt) * (d - this.dx);
    const cutoff = this.minCutoff + this.beta * Math.abs(this.dx);
    this.x += OneEuro.alpha(cutoff, dt) * (v - this.x);
    return this.x;
  }
}
