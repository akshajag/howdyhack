import type { Rng } from '../core/rng';

/**
 * Course data model. The course is a straight run along three.js -Z. Chunk-local "along" increases in the direction
 * of travel, so world z = chunk.zStart - along. Lateral x is shared between local and world space. Heights are world y
 * (water surface is y = 0).
 */
export type Mode = 'run' | 'surf' | 'swim';
export type Biome = 'beach' | 'pier' | 'lagoon' | 'coral' | 'grotto';
export type TidePhase = 'calm' | 'rising' | 'surge';

export type Shape =
  | { kind: 'box'; x: number; y: number; along: number; sx: number; sy: number; sz: number; yaw?: number }   // centre + full sizes (sy from y upward: box spans y..y+sy)
  | { kind: 'sphere'; x: number; y: number; along: number; r: number };

export interface Obstacle {
  shape: Shape;
  /** art tag for feedback ('rock', 'wood', 'coral', 'jelly', 'net', 'barrel'...). */
  tag: string;
  /** what the run-over screen says when this ends a run ('TRIPPED ON A LOG'); falls back to one per tag */
  name?: string;
  /** hitting it counts as a hit (default true); false = soft brush (kelp) that only slows */
  lethal?: boolean;
  /** eligible for near-miss scoring (default true) */
  nearMiss?: boolean;
  /** gentle bobbing (jellyfish) */
  bob?: { amp: number; freq: number; phase: number };
  /** this obstacle belongs to the risky line; passing it cleanly pays extra */
  risky?: boolean;
  /** pieces of one prop (an arch's rectangles) share a group so a pass scores one near miss, not several */
  group?: string;
}

export interface Prop {
  kit: string;
  x: number; y: number; along: number;
  yaw: number; scale: number;
  /** per-instance tint multiplier */
  tint?: [number, number, number];
  /** pitch/roll in radians for lying pieces */
  pitch?: number; roll?: number;
  /** extra vertical stretch (multiplies scale on y) */
  sy?: number;
}

/** A band of moving water. Inside it the player is pushed by (vx, vy, vAlong) m/s, feathered at the edges. */
export interface Current {
  x0: number; x1: number; along0: number; along1: number;
  y0?: number; y1?: number;
  vx: number; vy: number; vAlong: number;
  /** visualised as a stream (default true) */
  visible?: boolean;
  /** a gate hole's slipstream: every route through the gate goes through it (the validator counts its speed) */
  jet?: boolean;
}

export interface Pearl { x: number; y: number; along: number; value: number; risky?: boolean }

/** A hole in the walkable surface (pier gaps). Standing over it on the ground = fall. */
export interface Gap { along0: number; along1: number; x0: number; x1: number }

export type ChunkEventKind = 'zone' | 'surgeExit' | 'tide12';
export interface ChunkEvent { kind: ChunkEventKind; along: number; label?: string; sub?: string }

export interface Connector { mode: Mode; width: number; groundY: number }

/** Everything a pattern authors. Positions are chunk-local. */
export interface ChunkData {
  obstacles: Obstacle[];
  props: Prop[];
  currents: Current[];
  pearls: Pearl[];
  gaps: Gap[];
  events: ChunkEvent[];
  /** world height of the ground at (x, along) */
  ground: (x: number, along: number) => number;
  /** the surface the player runs/surfs on, if different from the visual ground (pier deck) */
  floor?: (x: number, along: number) => number | null;
  /** past this along the deck is over (open sea): leaving it is a dive, not a fall through the pier */
  deckEnd?: number;
  /** a cave roof: the height of its underside (Infinity where it's open water); swimmers stay below it */
  ceiling?: (x: number, along: number) => number;
  /** playable half width (soft walls beyond it) */
  width: number;
  /** optional risky route marker for HUD */
  riskyLine?: { x0: number; x1: number; along0: number; along1: number; bonus: number };
  /** first-run tutorial: the move each row teaches (lane = the lane index you must be in) */
  tutorial?: { step: 'lane' | 'jump' | 'slide'; along: number; lane?: number }[];
  /** holes in reef gates (centre x / world y, radius): swimming through one scores */
  rings?: { x: number; y: number; along: number; r: number }[];
  /** where the water is for FX ('none' land only, 'shallow' ankle deep, 'deep' underwater) */
  water: 'none' | 'shallow' | 'deep';
  /** side dressing selection handled by the biome, patterns may disable (open ocean) */
  sides?: boolean;
}

export interface PatternCtx {
  rng: Rng;
  /** 0..1 difficulty inside the tier */
  difficulty: number;
  tier: number;
  mirrored: boolean;
  tide: TidePhase;
  /** forward speed the player will have here (m/s), for fairness math */
  speed: number;
  length: number;
  /** world z of the chunk entrance (ground noise is sampled in world space so chunks join seamlessly) */
  zStart: number;
}

export interface Pattern {
  id: string;
  biome: Biome;
  mode: Mode;
  length: number;
  /** selection weight */
  weight: number;
  /** [minTier, maxTier] inclusive, tiers are 0..4 */
  tiers: [number, number];
  /** biome at the entrance and at the exit (equal for normal patterns) */
  from: Biome;
  to: Biome;
  /** special role in the grammar (transitions/intro) */
  role?: 'intro' | 'transition' | 'surge' | 'normal';
  build: (ctx: PatternCtx) => ChunkData;
}

export interface Chunk extends ChunkData {
  id: number;
  seq: number;
  biome: Biome;
  /** biome at the exit (differs on transitions) */
  toBiome: Biome;
  mode: Mode;
  patternId: string;
  length: number;
  zStart: number;
  tier: number;
  mirrored: boolean;
  tide: TidePhase;
  /** tide counter 1..12 for this chunk */
  tideStep: number;
  /** filled by the renderer */
  live?: unknown;
}

/** On foot (run / surf) the runner is in one of three lanes, Subway Surfers style; swimming is free in x and y. */
export const LANES = [-2.5, 0, 2.5] as const;
export const LANE_W = 2.5;
export const laneOf = (x: number) => Math.max(0, Math.min(2, Math.round(x / LANE_W) + 1));

/** Player movement capabilities. Shared by the controller and the generator's fairness validator. */
export const MOVE = {
  laneTime: 0.2,          // s to slide across one lane
  latSpeed: 8.0,          // m/s max lateral
  latAccel: 40.0,         // m/s^2
  jumpTime: 0.85,         // s airborne
  jumpHeight: 1.9,        // m apex (feet): high enough to sail over the coin line
  jumpClear: 1.35,        // m: the tallest obstacle that counts as jumpable (the feet stay above it for ~half the jump)
  pickupY: 0.65,          // m: on foot a coin is caught within this height of the hip (a jump passes over ground coins)
  slideTime: 0.75,        // s
  standHeight: 1.75,
  slideHeight: 0.85,
  radius: 0.38,
  swimVy: 4.5,            // m/s vertical underwater
  swimCeiling: -1.1,      // highest hip height while swimming (keeps the camera submerged)
  swimFloor: 0.9,         // min hip height above the seabed
  roofGap: 1.2,           // hip stays this far under a cave roof
  surgeBoost: 6.0,        // extra m/s during a surge
  surgeTime: 1.6,         // s
  surgeCooldown: 5.0,     // s
  reaction: 0.45,         // s of reaction time the validator reserves after a transition
  airTime: 14,            // s of breath under water; a reef-gate hole (bubbles) or the surface refills it
  airLow: 0.3,            // fraction where the low-air warning starts
};

/** Forward speed as a function of distance run (m). */
export function speedAt(distance: number): number {
  const t = Math.min(1, distance / 2000);
  return 12.5 + 10.5 * (1 - Math.pow(1 - t, 1.5));
}
export function tierAt(distance: number): number {
  return distance < 200 ? 0 : distance < 550 ? 1 : distance < 1000 ? 2 : distance < 1600 ? 3 : 4;
}
