import { OceanAudio } from './audio';

/**
 * Game sounds on top of the ocean ambience (still 100% synthesised: footsteps, splashes, jumps, slides, surges,
 * hits, pearls, tide horn, the 12th Tide breaker, game over, UI ticks) plus a layered procedural music bed whose
 * brightness and pulse follow the run's intensity.
 */
export class GameAudio extends OceanAudio {
  private nextChord = 0;
  private chordIdx = 0;
  private intensity = 0;
  private pulseT = 0;
  private droneGain: GainNode | null = null;
  volume = 0.8;

  setVolume(v: number) { this.volume = v; if (this.ctx && !this.muted) this.master.gain.setTargetAtTime(v, this.ctx.currentTime, 0.1); }
  get isMuted() { return this.muted; }
  setMuted(m: boolean) { if (m !== this.muted) this.toggleMute(); }

  /** 0 calm .. 1 the 12th tide */
  setIntensity(k: number) { this.intensity = Math.max(0, Math.min(1, k)); }

  private burst(freq: number, q: number, gain: number, dur: number, type: BiquadFilterType = 'bandpass', bus: AudioNode | null = null) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource(); src.buffer = this.noise;
    const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
    const g = ctx.createGain(); g.gain.setValueAtTime(gain, t); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    src.connect(f).connect(g).connect(bus ?? this.sfxBus); src.start(t, Math.random() * 4); src.stop(t + dur + 0.05);
  }
  private tone(freq: number, gain: number, dur: number, type: OscillatorType = 'sine', slide = 1, bus: AudioNode | null = null) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator(); o.type = type; o.frequency.setValueAtTime(freq, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, freq * slide), t + dur);
    const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(gain, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0006, t + dur);
    o.connect(g).connect(bus ?? this.sfxBus); o.start(t); o.stop(t + dur + 0.05);
  }

  footstep(surf: boolean) {
    if (surf) { this.burst(1800 + Math.random() * 800, 0.7, 0.08, 0.16, 'bandpass', this.airBus); this.burst(500, 0.8, 0.05, 0.08, 'lowpass', this.airBus); }
    else this.burst(700 + Math.random() * 300, 0.9, 0.07, 0.07, 'lowpass', this.airBus);
  }
  jump() { this.tone(260, 0.06, 0.18, 'sine', 1.8, this.airBus); this.burst(1400, 1.0, 0.05, 0.2, 'bandpass', this.airBus); }
  land(surf: boolean) { this.burst(320, 0.9, 0.12, 0.12, 'lowpass', this.airBus); if (surf) this.splash(0.6); }
  slide() { this.burst(900, 0.6, 0.1, 0.45, 'bandpass', this.airBus); }
  splash(size = 1) { this.burst(1600 + 800 * Math.random(), 0.5, 0.22 * size, 0.35 + 0.25 * size, 'bandpass', this.airBus); this.burst(400, 0.8, 0.12 * size, 0.2, 'lowpass', this.airBus); }
  surge() {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource(); src.buffer = this.noise;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = 1.6;
    f.frequency.setValueAtTime(300, t); f.frequency.exponentialRampToValueAtTime(3200, t + 0.5); f.frequency.exponentialRampToValueAtTime(600, t + 1.3);
    const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.3, t + 0.3); g.gain.exponentialRampToValueAtTime(0.001, t + 1.4);
    src.connect(f).connect(g).connect(this.sfxBus); src.start(t, Math.random() * 3); src.stop(t + 1.5);
    this.swell([50, 57, 62, 69], 1.6, 0.5);
  }
  hit(fatal: boolean) {
    this.thud(1);
    if (fatal) { this.tone(110, 0.25, 1.6, 'sawtooth', 0.4); this.tone(55, 0.3, 1.8, 'sine', 0.6); }
    else this.burst(2400, 0.8, 0.12, 0.3);
  }
  pearl(i: number) { this.chime(i % 12); }
  combo(level: number) { this.chime(Math.min(11, 4 + level * 2)); this.tone(880 + 120 * level, 0.03, 0.25, 'triangle', 1.3); }
  tideWarn() {
    this.tone(98, 0.14, 1.4, 'sawtooth', 1.0, this.musicBus); this.tone(147, 0.09, 1.4, 'sawtooth', 1.0, this.musicBus);
    setTimeout(() => { this.tone(110, 0.14, 1.8, 'sawtooth', 1.0, this.musicBus); this.tone(165, 0.09, 1.8, 'sawtooth', 1.0, this.musicBus); }, 700);
  }
  tideBreak() {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource(); src.buffer = this.noise;
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.setValueAtTime(200, t); f.frequency.linearRampToValueAtTime(3000, t + 2.2); f.frequency.linearRampToValueAtTime(400, t + 5);
    const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.6, t + 2.0); g.gain.exponentialRampToValueAtTime(0.001, t + 5.5);
    src.connect(f).connect(g).connect(this.master); src.start(t, Math.random() * 2); src.stop(t + 6);
    this.tone(40, 0.5, 3.5, 'sine', 0.7, this.master);
    this.swell([38, 45, 50, 57, 62], 4.5, 1.0, 0.8);
  }
  tideSurvived() { this.bank(5000); this.swell([50, 57, 62, 66, 69], 3.5, 0.9); }
  gameOver() { [74, 69, 62].forEach((m, i) => this.bell(m, i * 0.35, 0.05)); this.tone(55, 0.2, 2.5, 'sine', 0.8, this.musicBus); }
  click() { this.tone(1200, 0.03, 0.05, 'square', 0.7, this.master); }
  /** a gull's cry as it dives */
  gull() { this.tone(1500, 0.05, 0.22, 'triangle', 0.55, this.airBus); this.tone(1250, 0.04, 0.28, 'triangle', 0.6, this.airBus); }
  /** a cannon fires: a low boom with a crack on top */
  cannon() { this.burst(140, 0.8, 0.32, 0.9, 'lowpass'); this.burst(900, 0.6, 0.12, 0.25, 'bandpass'); this.tone(55, 0.2, 0.6, 'sine', 0.6, this.sfxBus); }
  /** a chest flies open: a bright little arpeggio */
  treasure() { [84, 88, 91, 96].forEach((m, i) => this.bell(m, i * 0.06, 0.035)); }
  /** dun-dun: a shark is coming */
  shark() { this.tone(82, 0.22, 0.42, 'sawtooth', 0.98, this.musicBus); this.burst(160, 1.2, 0.08, 0.3, 'lowpass'); setTimeout(() => this.tone(87, 0.24, 0.5, 'sawtooth', 0.98, this.musicBus), 380); }
  /** wingbeats: a few gulls taking off */
  flutter(n = 7) {
    const ctx = this.ctx; if (!ctx) return;
    const t0 = ctx.currentTime;
    for (let i = 0; i < n; i++) {
      const t = t0 + i * 0.065 + Math.random() * 0.03;
      const src = ctx.createBufferSource(); src.buffer = this.noise;
      const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 800 + Math.random() * 600; f.Q.value = 0.9;
      const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.06 * (1 - i / (n + 2)), t + 0.012); g.gain.exponentialRampToValueAtTime(0.0008, t + 0.06);
      src.connect(f).connect(g).connect(this.airBus ?? this.sfxBus); src.start(t, Math.random() * 3); src.stop(t + 0.08);
    }
  }
  /** two falling chimes: breath is running low */
  airLow() { this.bell(81, 0, 0.05); this.bell(76, 0.2, 0.05); }
  /** a gulp of bubbles: air refilled at a gate */
  airRefill() { this.burst(2200, 0.7, 0.07, 0.3, 'bandpass', this.airBus); this.tone(520, 0.03, 0.18, 'sine', 1.6, this.airBus); }
  waveBuild() { this.burst(600, 0.5, 0.25, 1.6, 'lowpass'); this.tone(70, 0.18, 1.8, 'sine', 1.3, this.musicBus); }

  /** per frame: schedule the music bed */
  music(dt: number) {
    const ctx = this.ctx; if (!ctx) return;
    const t = ctx.currentTime;
    const k = this.intensity;
    if (t > this.nextChord) {
      const P: number[][] = [[50, 57, 62, 64, 66], [47, 54, 59, 62, 64], [43, 50, 55, 59, 61], [45, 52, 57, 59, 64]];
      const dark: number[][] = [[50, 53, 57, 60, 65], [48, 51, 55, 60, 63], [46, 53, 58, 60, 65], [45, 52, 55, 60, 64]];
      const ch = (k > 0.6 ? dark : P)[this.chordIdx % 4];
      const dur = 6.5 - 2.5 * k;
      this.swell(ch, dur, 0.35 + 0.55 * k);
      this.chordIdx++;
      this.nextChord = t + dur * 0.62;
    }
    // pulse arpeggio when things get intense
    if (k > 0.35) {
      this.pulseT += dt;
      const period = 0.5 - 0.22 * k;
      if (this.pulseT > period) { this.pulseT = 0; const arp = [74, 78, 81, 86]; this.bell(arp[this.chordIdx % 4] + (k > 0.7 ? -2 : 0), 0, 0.012 + 0.02 * k); }
    }
    void this.droneGain;
  }
}
