import type { HandTracker } from '../game/hand';
import { HAND_SETTINGS } from '../game/hand';

/**
 * Menu shell: title, control choice, webcam setup + calibration, how to play, settings, pause, game over.
 * Pure DOM, no framework. Every button does something real; the game shell wires the callbacks.
 */
export type Screen = 'none' | 'title' | 'setup' | 'howto' | 'settings' | 'pause' | 'over' | 'handlost';

export interface Settings { volume: number; muted: boolean; sensitivity: number; quality: 'auto' | 'low' | 'medium' | 'high'; seed: string; mirror: boolean }

export class Menus {
  readonly root: HTMLElement;
  screen: Screen = 'none';
  settings: Settings = { volume: 0.8, muted: false, sensitivity: 1, quality: 'auto', seed: '', mirror: true };
  onPlay: ((withCamera: boolean) => void) | null = null;
  /** replay the first-run tutorial */
  onTutorial: (() => void) | null = null;
  onResume: (() => void) | null = null;
  onRestart: (() => void) | null = null;
  onMenu: (() => void) | null = null;
  onSettings: ((s: Settings) => void) | null = null;
  onStartCamera: (() => Promise<boolean>) | null = null;
  /** the camera setup screen opened (the game shell switches to its setup state so the screen updates every frame) */
  onSetupOpen: (() => void) | null = null;
  onRecalibrate: (() => void) | null = null;
  onClick: (() => void) | null = null;
  private hand: HandTracker | null = null;
  private preview: HTMLCanvasElement;
  private previewTimer = 0;

  constructor() {
    try { Object.assign(this.settings, JSON.parse(localStorage.getItem('t12.settings') ?? '{}')); } catch { /* */ }
    const r = document.createElement('div');
    r.id = 'menus';
    r.innerHTML = `
      <section class="scr s-title">
        <div class="t-brand"><div class="t-kicker">RUN · SURF · SWIM</div><h1>THE 12<sup>TH</sup> TIDE</h1><div class="t-sub">A coastal endless runner. Every twelfth tide, the ocean comes for you.</div></div>
        <div class="t-btns">
          <button class="primary b-play-cam">▶ Play with hand camera</button>
          <button class="b-play-key">Play with keyboard</button>
          <div class="row"><button class="b-howto">How to play</button><button class="b-settings">Settings</button></div>
        </div>
        <div class="t-foot"><span class="t-best"></span><span class="t-hint">Space / Enter starts with the keyboard</span></div>
      </section>
      <section class="scr s-setup">
        <div class="panel">
          <div class="p-kicker">HAND CAMERA</div><h2>Your hand is the controller</h2>
          <div class="setup-grid">
            <div class="cam-col"><canvas class="setup-preview" width="320" height="240"></canvas><div class="cam-state">requesting camera…</div></div>
            <div class="how-col">
              <ul class="how">
                <li><b>Rest your elbow</b> on the desk or an armrest, open hand at chin height, palm to the camera. Hold still for a second: that's your rest spot.</li>
                <li><b>Move your hand left, centre or right</b> to pick a lane.</li>
                <li><b>Flick up</b> to jump, <b>flick down</b> to slide (or raise / lower it slowly and further).</li>
                <li><b>Close your fist</b> for a short surge of speed. Under water, <b>your hand is where you swim</b>.</li>
              </ul>
              <label class="slider">Sensitivity <input type="range" class="i-sens" min="0.6" max="1.8" step="0.05"><span class="v-sens"></span></label>
            </div>
          </div>
          <div class="p-btns"><button class="primary b-setup-go" disabled>Start when calibrated</button><button class="b-recal">Recalibrate</button><button class="b-setup-key">Use keyboard instead</button><button class="b-back">Back</button></div>
        </div>
      </section>
      <section class="scr s-howto">
        <div class="panel">
          <div class="p-kicker">HOW TO PLAY</div><h2>Survive the coast. Beat your best.</h2>
          <div class="cols">
            <div><h3>Hand camera</h3><table><tr><td>Switch lanes</td><td>hand left / centre / right</td></tr><tr><td>Jump</td><td>flick up</td></tr><tr><td>Slide</td><td>flick down</td></tr><tr><td>Swim</td><td>your hand is where you swim (under water)</td></tr><tr><td>Surge</td><td>close fist</td></tr></table></div>
            <div><h3>Keyboard</h3><table><tr><td>Switch lanes</td><td>tap A / D or ← →</td></tr><tr><td>Steer (under water)</td><td>hold A / D</td></tr><tr><td>Jump</td><td>Space or W / ↑</td></tr><tr><td>Slide</td><td>S / ↓</td></tr><tr><td>Swim up / down</td><td>W / S (under water)</td></tr><tr><td>Surge</td><td>Shift</td></tr><tr><td>Pause</td><td>Esc</td></tr><tr><td>Restart</td><td>R</td></tr></table></div>
          </div>
          <ul class="tips">
            <li><b>Near misses</b> pay. Skim an obstacle without touching it to raise your combo.</li>
            <li>On foot there are <b>three lanes</b>. Every rock, log and barrel can be jumped; beams, nets and raised palms are slid under. Under water you swim freely.</li><li><b>Currents</b> are drifting streaks. Sideways ones carry you a lane over; forward ones are fast lanes worth more.</li>
            <li><b>Pink pearls</b> mark the risky line: faster, tighter, worth more.</li>
            <li>The <b>tide counter</b> climbs with every section. On the <b>12th</b>, a surge floods the coast. Survive it for a big bonus and a fresh shield.</li>
            <li>You start with <b>one shield</b>. The second hit ends the run.</li>
          </ul>
          <div class="p-btns"><button class="primary b-tutorial">Play the tutorial</button><button class="b-back">Back</button></div>
        </div>
      </section>
      <section class="scr s-settings">
        <div class="panel">
          <div class="p-kicker">SETTINGS</div><h2>Settings</h2>
          <label class="slider">Sound volume <input type="range" class="i-vol" min="0" max="1" step="0.05"><span class="v-vol"></span></label>
          <label class="check"><input type="checkbox" class="i-mute"> Mute (M)</label>
          <label class="slider">Camera sensitivity <input type="range" class="i-sens2" min="0.6" max="1.8" step="0.05"><span class="v-sens2"></span></label>
          <label class="select">Graphics quality <select class="i-quality"><option value="auto">Auto</option><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></label>
          <label class="text">Course seed <input type="text" class="i-seed" placeholder="random each run" maxlength="16"><span class="hint">Same seed, same course. Leave empty for a new one every run.</span></label>
          <details class="credits"><summary>Credits</summary>
            <p>Design, code, shaders, Blender kits and all audio are original to The 12th Tide.</p>
            <p>Runner: “Beach Character” and its animations by Quaternius (poly.pizza, CC0); jump and swim clips by The 12th Tide.</p>
            <p>Beach: props, palms, rocks, boats and plants from the Pirate Kit and Nature Kit by Kenney (kenney.nl, CC0) · sand texture “Sand 01” by Rob Tuytel (Poly Haven, CC0).</p>
            <p>Models: “Jellyfish”, “Starfish”, “Seashell”, “Sea anemone” by Poly by Google (poly.pizza), CC-BY 3.0 · “seashell” by Dario Demi (D911C) (poly.pizza), CC-BY 3.0 · “Ship wheel” by Hero.Craft (sketchfab.com), CC-BY 4.0 · Anchor, Chest, palm and nature kit by Quaternius (CC0) · Cannon by James Ray Cock and Yann Kervran, coastal cliffs by Rob Tuytel and Rico Cilliers (Poly Haven, CC0) · palms by FabinhoSC (OpenGameArt, CC0).</p>
            <p>Libraries: Three.js (MIT, © three.js authors) · lil-gui (MIT) · MediaPipe Tasks Vision (Apache-2.0).</p>
          </details>
          <div class="p-btns"><button class="primary b-tutorial">Play the tutorial</button><button class="b-back">Back</button></div>
        </div>
      </section>
      <section class="scr s-pause">
        <div class="panel small"><div class="p-kicker">PAUSED</div><h2>Take a breath</h2>
          <div class="p-btns col"><button class="primary b-resume">Resume (Esc)</button><button class="b-restart">Restart (R)</button><button class="b-menu">Main menu</button></div></div>
      </section>
      <section class="scr s-handlost">
        <div class="panel small"><div class="p-kicker">HAND NOT FOUND</div><h2>Show your hand to continue</h2><p>The run is paused until the camera sees your open palm again.</p>
          <div class="p-btns col"><button class="b-setup-key2">Switch to keyboard</button><button class="b-menu">Main menu</button></div></div>
      </section>
      <section class="scr s-over">
        <div class="panel">
          <div class="p-kicker o-kicker">WASHED OUT</div><div class="o-score">0</div><div class="o-best"></div>
          <div class="o-grid"></div>
          <div class="p-btns"><button class="primary b-restart">Run again (R)</button><button class="b-menu">Main menu</button></div>
        </div>
      </section>`;
    document.body.appendChild(r);
    this.root = r;
    this.preview = r.querySelector('.setup-preview') as HTMLCanvasElement;
    const q = (s: string) => r.querySelector(s) as HTMLElement;
    const on = (sel: string, fn: () => void) => r.querySelectorAll(sel).forEach((b) => ((b as HTMLElement).onclick = () => { this.onClick?.(); fn(); }));
    on('.b-play-cam', () => this.beginSetup());
    on('.b-play-key', () => this.onPlay?.(false));
    on('.b-howto', () => this.show('howto'));
    on('.b-tutorial', () => this.onTutorial?.());
    on('.b-settings', () => this.show('settings'));
    on('.b-back', () => this.show('title'));
    on('.b-setup-go', () => this.onPlay?.(true));
    on('.b-setup-key', () => this.onPlay?.(false));
    on('.b-setup-key2', () => this.onPlay?.(false));
    on('.b-recal', () => this.onRecalibrate?.());
    on('.b-resume', () => this.onResume?.());
    on('.b-restart', () => this.onRestart?.());
    on('.b-menu', () => this.onMenu?.());
    const s = this.settings;
    const bindRange = (sel: string, vsel: string, key: 'volume' | 'sensitivity', fmt: (v: number) => string) => {
      const i = q(sel) as HTMLInputElement, v = q(vsel);
      i.value = String(s[key]); v.textContent = fmt(s[key]);
      i.oninput = () => { s[key] = +i.value; v.textContent = fmt(s[key]); this.apply(); };
    };
    bindRange('.i-vol', '.v-vol', 'volume', (v) => `${Math.round(v * 100)}%`);
    bindRange('.i-sens', '.v-sens', 'sensitivity', (v) => `${v.toFixed(2)}×`);
    bindRange('.i-sens2', '.v-sens2', 'sensitivity', (v) => `${v.toFixed(2)}×`);
    const mute = q('.i-mute') as HTMLInputElement; mute.checked = s.muted; mute.onchange = () => { s.muted = mute.checked; this.apply(); };
    const qual = q('.i-quality') as HTMLSelectElement; qual.value = s.quality; qual.onchange = () => { s.quality = qual.value as Settings['quality']; this.apply(); };
    const seed = q('.i-seed') as HTMLInputElement; seed.value = s.seed; seed.oninput = () => { s.seed = seed.value.trim(); this.apply(); };
    this.apply(false);
  }

  private apply(notify = true) {
    HAND_SETTINGS.sensitivity = this.settings.sensitivity;
    try { localStorage.setItem('t12.settings', JSON.stringify(this.settings)); } catch { /* */ }
    (this.root.querySelector('.i-sens') as HTMLInputElement).value = String(this.settings.sensitivity);
    (this.root.querySelector('.i-sens2') as HTMLInputElement).value = String(this.settings.sensitivity);
    (this.root.querySelector('.v-sens') as HTMLElement).textContent = `${this.settings.sensitivity.toFixed(2)}×`;
    (this.root.querySelector('.v-sens2') as HTMLElement).textContent = `${this.settings.sensitivity.toFixed(2)}×`;
    if (notify) this.onSettings?.(this.settings);
  }

  setMuted(m: boolean) { this.settings.muted = m; (this.root.querySelector('.i-mute') as HTMLInputElement).checked = m; this.apply(false); }

  show(s: Screen) {
    this.screen = s;
    this.root.querySelectorAll('.scr').forEach((e) => e.classList.remove('show'));
    if (s !== 'none') this.root.querySelector(`.s-${s}`)?.classList.add('show');
    this.root.classList.toggle('show', s !== 'none');
  }

  setBest(score: number, dist: number) { (this.root.querySelector('.t-best') as HTMLElement).textContent = score > 0 ? `Personal best ${score.toLocaleString()} · ${Math.round(dist)} m` : 'No runs yet. The tide is waiting.'; }

  attachHand(h: HandTracker) { this.hand = h; }

  private async beginSetup() {
    this.show('setup');
    this.onSetupOpen?.();
    const state = this.root.querySelector('.cam-state') as HTMLElement;
    const go = this.root.querySelector('.b-setup-go') as HTMLButtonElement;
    go.disabled = true;
    state.textContent = 'requesting camera… (allow access in the browser prompt)';
    const ok = await this.onStartCamera?.();
    if (!ok) { state.textContent = `camera unavailable: ${this.hand?.error ?? 'permission denied'}. You can still play with the keyboard.`; return; }
  }

  /** per frame while the setup screen is open */
  updateSetup(dt: number) {
    if (this.screen !== 'setup' || !this.hand) return;
    this.previewTimer += dt;
    const h = this.hand;
    h.drawPreview(this.preview);
    const state = this.root.querySelector('.cam-state') as HTMLElement;
    const go = this.root.querySelector('.b-setup-go') as HTMLButtonElement;
    const msg: Record<string, string> = {
      off: '', loading: 'loading hand tracking… (first time downloads the model)', calibrating: h.hint || (h.raw ? 'hand found. hold it still…' : 'rest your elbow and show your open hand to the camera'),
      tracking: `calibrated · ${h.usingWorker ? 'worker' : 'main thread'} · ${h.inferenceMs.toFixed(0)} ms`, lost: 'hand lost. show your palm', error: `camera error: ${h.error}`,
    };
    state.textContent = msg[h.status];
    const ready = h.status === 'tracking' || h.status === 'lost';
    go.disabled = !ready;
    go.textContent = ready ? 'Start the run' : 'Start when calibrated';
  }

  gameOver(s: { score: number; best: number; newBest: boolean; distance: number; maxMult: number; nearMisses: number; pearls: number; tides: number; risky: number; cause: string }) {
    const r = this.root;
    (r.querySelector('.o-kicker') as HTMLElement).textContent = s.cause;
    (r.querySelector('.o-score') as HTMLElement).textContent = s.score.toLocaleString();
    const b = r.querySelector('.o-best') as HTMLElement;
    b.textContent = s.newBest ? 'NEW PERSONAL BEST' : `Personal best ${s.best.toLocaleString()}`;
    b.classList.toggle('new', s.newBest);
    (r.querySelector('.o-grid') as HTMLElement).innerHTML = [
      ['Distance', `${Math.round(s.distance).toLocaleString()} m`], ['Best combo', `×${s.maxMult.toFixed(1)}`], ['Near misses', `${s.nearMisses}`],
      ['Pearls', `${s.pearls}`], ['Risky lines', `${s.risky}`], ['12th Tides survived', `${s.tides}`],
    ].map(([k, v]) => `<div><span>${k}</span><b>${v}</b></div>`).join('');
    this.show('over');
  }
}
