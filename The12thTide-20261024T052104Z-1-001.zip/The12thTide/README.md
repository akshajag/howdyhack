# The 12th Tide

A coastal endless runner for the browser. You sprint along a tropical beach, race a broken pier, dive into the sea (or off the end of the pier) into a coral canyon, thread its reef gates and a shipwreck grotto, steering with **your hand in front of the webcam** (or the keyboard). The course is assembled from authored, seeded chunks, so every run is different. A tide counter climbs with every section; on the **12th tide** the ocean surges over the coast and you have to ride it out.

Three.js + TypeScript. Environments are built in Blender (through the Blender MCP) and exported as modular GLBs. All sound is synthesised at runtime.

| Beach | Pier | Diving in |
|---|---|---|
| ![](docs/runner/final/beach.png) | ![](docs/runner/final/pier.png) | ![](docs/runner/final/dive.png) |

| Reef gates | The 12th Tide under water | Shipwreck Grotto |
|---|---|---|
| ![](docs/runner/final/gates.png) | ![](docs/runner/final/coral.png) | ![](docs/runner/final/grotto.png) |

## Run it

```bash
cd game
npm install
npm run dev        # http://127.0.0.1:5173
npm run build      # type-check + production bundle in game/dist
npm run preview    # serve the production build
```

Needs a WebGL2 browser. The hand camera needs `getUserMedia` (Chrome, Edge, Safari 17+, Firefox) and downloads MediaPipe's hand model (about 8 MB) from the CDN on first use; after that the game runs with no network.

## Controls

| | Hand camera | Keyboard |
|---|---|---|
| Switch lanes (on foot) | hold your hand left / centre / right | tap A / D or ← / → |
| Steer (under water) | move your hand | hold A / D |
| Jump (on land) | raise your hand | Space, W or ↑ |
| Slide (on land) | drop your hand | S or ↓ |
| Swim up / down (under water) | hand up / down | W / S or ↑ / ↓ |
| Surge (short speed burst, cooldown) | close your fist | Shift |
| Pause / resume | | Esc |
| Restart | | R (also Enter on the results screen) |
| Mute | | M |

The hand controller works with either hand, and everything is measured in palm lengths, so it feels the same near or far from the camera. Rest your elbow and hold your open hand at chin height to calibrate (it tells you to move to the middle of the picture, closer or back if needed). Left / centre / right picks the lane; a quick flick up jumps and a flick down slides (or a slow, bigger raise or drop). Bringing your hand back to rest never counts as the opposite move, a jump locks out slides for a moment (and the other way round), and nothing fires just after a lane change. A closed fist (held for a few frames) surges. Under water your hand is where you swim. If the hand is lost you keep your lane; after 1.5 s the run pauses and it resumes once the hand is tracked steadily again. The in-run strip under the runner shows your lane zone, flashes ▲ / ▼ when a jump or slide registers, and a dot shows the tracking speed. Sensitivity is in Settings.

The first run is an interactive tutorial (change lanes, jump, slide, back to the middle): the game slows to a near stop at each row until you make the move. Replay it from How to play.

## How it plays

- **Score** = distance × combo, plus near misses, pearls, risky lines and current rides.
- **Combo** (×1 … ×8) climbs with near misses, risky lines and ridden currents; it decays after six idle seconds and resets when you take a hit.
- **Shield**: you start with one. The second hit ends the run. Surviving a 12th Tide restores it.
- **Pearls** mark the intended lines; **pink pearls** mark the risky line (tighter, faster, worth more).
- **Currents** are drawn as drifting streaks: ride them for speed and points, or get pushed into the rocks.
- **Into the water**: run into the sea, or off the end of the pier, and you dive; a tidal surge carries you back up onto the beach.
- **The 12th Tide under water** is a rip current through a run of reef gates with one kind of hazard between them (tumbling cargo or a rock pillar); the bonus coins go through the harder hole of a twin gate.
- **Under water** each area has one kind of obstacle and ends at a reef gate: a coral forest, a run of reef gates with a mine between each hole, side currents sweeping you toward coral towers, a jellyfish curtain, a minefield (rows of moored mines across the canyon, one way through each), fishing nets (hanging from the surface: go under; standing on the seabed: go over), and shark waters (sharks cross at your depth after a two-note warning: swim up or down). In the grotto: the wreck's hull ribs, curtains of chains from the roof, or the wreck's mines. Reef walls cross the whole canyon; the only way on is through a glowing hole, which pays a bonus that grows with each gate in a row, gives a slipstream boost, and refills your **air** (14 s on the O₂ meter). Run out of air and you lose your shield, or the run.
- **The Shipwreck Grotto** is lower than the canyon: the seabed slopes down about 8 m to a cave mouth in a rock wall, and inside a stalactite roof caps the swim space in the dark. An up-current carries you back out.
- **Cannons and treasure**: cannons fire one slow cannonball down their lane when you're ~70 m away (a boom and smoke): jump it, or step aside. It only fires where the ball meets you clear of everything else in that lane. Jump a treasure chest and its lid flies open in a shower of sparkle for a bonus.
- **Critters**: from 200 m, crabs scuttle sideways across the beach (jump them); from 550 m, gulls dive at your lane. Their shadow grows on the sand first, so change lanes or slide. They only appear where the dodge is always possible.
- **Aggie touches**: a seaside research station with a maroon roof at the start, a HOWDY! sign you run past, a Reveille-inspired collie with a maroon collar sitting by the station steps (it turns to watch you go), maroon-and-white ocean research buoys round the pier and offshore, and the runner's dark wetsuit top, maroon trunks and a dive pack with a white 12.
- **Wildlife** (nothing to dodge, just life): gulls standing on the sand and along the pier rails flap away as you run up, more wheel overhead, dolphin pods leap beside the beach for a few jumps, and sailboats drift on the horizon. Under water, fish schools part around you, mantas glide past, sea turtles paddle by, and in the dark grotto glowing plankton swirls in your wake.
- **It gets harder quickly**: speed climbs from 12.5 to 23 m/s over the first 2 km, and the difficulty tier steps up at 200, 550, 1,000 and 1,600 m. Each step adds more walled-off lanes, denser rows mixing jumps and slides, reef gates closer together, and jellyfish beside the holes.
- **The tide**: calm for sections 1–8, rising for 9–11 (the sea creeps up the beach, currents strengthen, the sky darkens), and on 12 the surge arrives: the coast floods and the pink line pays double. Under water the surge is a rip current full of debris.

URL parameters for testing: `?seed=ABC123` (fixed course), `?quality=Low|Medium|High`, `?tutorial=0` (skip the first-run tutorial), `?autostart=1`, `?debug=1` (frame stats, backtick toggles), `?clean=1` (no UI), `?mute=1`, `?pose=run|swim|jump|slide` (character inspector).

## Repository layout

```
game/                 the web game (Vite + TypeScript + Three.js)
  src/main.ts           game shell: renderer, state machine, event wiring
  src/game/             runner, chunks, generator, validator, patterns/, tide, scoring, hand, camera, character, critters, wildlife
  src/world/            sky, water, materials, pools, ground, atmosphere, fauna, kit catalogue
  src/fx/               post pipeline, god rays, marine snow, current streaks, shield bubble
  src/systems/          audio (all synthesised), adaptive quality, fish
  src/ui/               menus, HUD, styles
  public/models/        reef kit (ours)      public/cove/models/   cove kit (ours + restyled CC0)
  public/runner/        runner kit + manifest.json (ours + 9 credited library imports)
blender/              Blender sources and build scripts (runner_kit.blend, runner/*.py, older kits)
tools/                headless test harness: gentest, runshot, keytest, handtest, poseshot, evalshot, glbinfo
docs/                 ARCHITECTURE.md, TEST_REPORT.md, screenshots, older design notes
archive/              the previous Tide Run prototype (not compiled)
ASSET_CREDITS.md      every third-party asset and library, with licences
```

## Tests

```bash
node tools/gentest.mjs 1000 40      # 1,000 seeded courses: route reachability, grammar, seams, 12th Tide schedule
node tools/runshot.mjs 60 SEED      # a bot plays for 60 s in GPU Chrome; screenshots + console errors + frame stats
node tools/keytest.mjs              # real key events: steer, jump, slide, surge, pause, restart
node tools/handtest.mjs             # MediaPipe pipeline with a fake camera + synthetic-landmark gesture tests
node tools/handcamtest.mjs hand.y4m # a real hand (video from a photo) through Chrome's fake camera: lanes, jump, slide
node tools/hitboxaudit.mjs          # every hitbox must sit inside the model drawn there
```

See [docs/TEST_REPORT.md](docs/TEST_REPORT.md) for the results and what remains unverified (a real hand on a real webcam, for one).

## Credits

Design, code, shaders, Blender kits and audio are original to this project. Third-party items: Three.js (MIT), lil-gui (MIT), MediaPipe Tasks Vision (Apache-2.0, loaded at runtime), and the models listed in [ASSET_CREDITS.md](ASSET_CREDITS.md) (CC0 and CC-BY; the CC-BY authors are named in the in-game Settings → Credits panel).
