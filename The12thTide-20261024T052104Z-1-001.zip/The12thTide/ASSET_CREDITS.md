# Asset and code credits

Everything not listed here is original to this project: the game code and shaders, the procedural audio, the Blender build scripts and the kit pieces they produce (reef kit in `game/public/models`, most of the cove kit in `game/public/cove/models`, 54 of the 99 runner-kit pieces in `game/public/runner/models` (including the reef gates, their rings, the volleyball net, the grotto's cave mouth and roof, the sea mine, the fishing net, the crab and the shark, the wildlife: gulls, dolphin, sea turtle, sailboat, and the Aggie details: research station, HOWDY! sign, research buoys, the collie, the runner's dive pack, and the treasure chest), and the `Runner_Character`).

Detailed provenance notes, including items that were evaluated and rejected, are in [docs/ASSETS_AND_LICENSES.md](docs/ASSETS_AND_LICENSES.md).

## Software

| Package | Version | Licence | Shipped? |
|---|---|---|---|
| [three](https://threejs.org) (incl. `GLTFLoader`) | 0.186.1 | MIT, © 2010-2026 three.js authors | yes (bundled) |
| [lil-gui](https://lil-gui.georgealways.com) | 0.21.0 | MIT | yes (debug panel) |
| [@mediapipe/tasks-vision](https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker/web_js) | 1.0.1 | Apache-2.0 | loaded from jsDelivr at runtime, not bundled; the hand model (`hand_landmarker.task`) is downloaded from Google's storage |
| vite 7.3.7, typescript 5.9.3, @types/three, puppeteer-core 24 | | MIT / Apache-2.0 | build and test tools only |
| Blender 5.2 + glTF exporter | | GPL (the exported meshes are ours) | authoring tool only |

No code was copied from the repositories studied while designing the game (listed in `docs/research-notes.md` and `docs/tide/TIDE_RUN.md`).

## 3D models imported from libraries

All imports were brought in through the Blender MCP (Poly Haven, Sketchfab, Poly Pizza), then merged to one mesh, decimated, re-pivoted to the base centre, scaled to real size and had their textures baked into vertex colours, so no third-party texture images ship.

### The runner (`game/public/runner/models/Runner_Beach.glb`)

"Beach Character" by **Quaternius**, [poly.pizza/m/DojKLcO34E](https://poly.pizza/m/DojKLcO34E), **CC0 1.0**. Rig and the Idle, Run, Roll, Hit (HitRecieve), Death and Wave clips are Quaternius' own animation. Changes: the board shorts recoloured maroon, unused clips removed, and two clips added on the same rig by this project (`blender/runner/author_q_clips.py`): **Jump** and a front-crawl **Swim**. Played with three.js' `AnimationMixer` (MIT). The earlier procedural `Runner_Character.glb` is no longer used.

### Runner kit (`game/public/runner/models`)

| Piece | Source | Author | Licence |
|---|---|---|---|
| `Anchor` | [poly.pizza/m/ejWQny9Gcz](https://poly.pizza/m/ejWQny9Gcz) | Quaternius | CC0 1.0 |
| `Chest` | [poly.pizza/m/AngpV0HxD8](https://poly.pizza/m/AngpV0HxD8) | Quaternius | CC0 1.0 |
| `Cannon` | [polyhaven.com/a/cannon_01](https://polyhaven.com/a/cannon_01) | James Ray Cock, Yann Kervran | CC0 1.0 |
| `Jellyfish` | [poly.pizza/m/5PxIqPamrag](https://poly.pizza/m/5PxIqPamrag) | Poly by Google | **CC-BY 3.0** |
| `Starfish` | [poly.pizza/m/6H-0K9IEr56](https://poly.pizza/m/6H-0K9IEr56) | Poly by Google | **CC-BY 3.0** |
| `Shell_A` ("Seashell") | [poly.pizza/m/5ovn4mnRejL](https://poly.pizza/m/5ovn4mnRejL) | Poly by Google | **CC-BY 3.0** |
| `Shell_B` ("seashell") | [poly.pizza/m/2BU9U8dOkh-](https://poly.pizza/m/2BU9U8dOkh-) | Dario Demi (D911C) | **CC-BY 3.0** |
| `Anemone` ("Sea anemone") | [poly.pizza/m/5mWGVL6VgMd](https://poly.pizza/m/5mWGVL6VgMd) | Poly by Google | **CC-BY 3.0** |
| `Ship_Wheel` | [sketchfab.com/3d-models/ff5cf353988d48bb8303f452096736f9](https://sketchfab.com/3d-models/ff5cf353988d48bb8303f452096736f9) | Hero.Craft | **CC-BY 4.0** |

### Kenney kits (`game/public/runner/models/K_*.glb`: beach obstacles and dressing)

Downloaded from kenney.nl and converted by `blender/runner/import_kenney.py`: the palette texture / flat materials baked into vertex colours, recoloured to the game's palette (brown wood instead of Kenney's orange-red, yellow-green foliage, grey-tan beach stone, limestone tower), resized to metres and re-pivoted. `K_Palm_Fallen` and `K_Palm_Raised` are composites built from a Kenney palm (laid down, trunk thinned so it can be jumped) and Kenney rocks. Download links and the exact source files are in `assets_vendor/kenney/*/SOURCE.txt`.

| Pieces | Source | Author | Licence |
|---|---|---|---|
| `K_Rock_SandA/SandC/C`, `K_Rocks_Big/BigA`, `K_Barrel`, `K_Crate`, `K_Crate_Bottles`, `K_Chest`, `K_Cannon`, `K_Palm_Bend/Straight/Small`, `K_Grass`, `K_Rowboat`, `K_Hut`, `K_Watchtower`, `K_Flag`, `K_Shipwreck`, composites `K_Palm_Fallen`, `K_Palm_Raised`, `K_Barrels`, `K_CrateStack`, `K_BoatRack` (the boat rack's posts are ours) | [Pirate Kit 2.1](https://kenney.nl/assets/pirate-kit) | Kenney | CC0 1.0 |
| `K_Log`, `K_LogBig`, `K_LogPile`, `K_Tiki` (statue head), `K_Bush`, `K_Bush_Large`, `K_Grass_Tall`, `K_Flowers`, `K_Flowers_Red`, `K_Canoe`, `K_Campfire`, `K_Fence` | [Nature Kit 2.1](https://kenney.nl/assets/nature-kit) | Kenney | CC0 1.0 |

`K_VolleyNet`, `Reef_Gate_Mid/Low/High/Twin` and `Gate_Ring` are ours (`import_kenney.py`, `build_gates.py`).

### Textures

| Texture | Source | Author | Licence |
|---|---|---|---|
| `runner/textures/sand_01_*` (beach ground detail: grain and normal, tinted by our ground colours) | [polyhaven.com/a/sand_01](https://polyhaven.com/a/sand_01) | Rob Tuytel / Poly Haven | CC0 1.0 |

Research for the beach rebuild (no code or assets taken): Blender beach-building guides (CG Cookie's beach-scene series) and the OpenGameArt listing of the Kenney Pirate Kit.

### Cove kit (`game/public/cove/models`, earlier beach dressing; the files still ship)

| Piece | Source | Author | Licence |
|---|---|---|---|
| `SRC_coastal_cliff_01/02`, `SRC_rock_face_01/02` | [polyhaven.com](https://polyhaven.com/a/coastal_cliff_01) | Rob Tuytel, Rico Cilliers / Poly Haven | CC0 1.0 (geometry only, decimated and re-shaded) |
| `SRC_palm` | [poly.pizza/m/nr1B5DbICA](https://poly.pizza/m/nr1B5DbICA) | Quaternius | CC0 1.0 |
| `SRC_mk_rock_1/2/3`, `SRC_mk_bush`, `SRC_mk_grass_wispy` | [Stylized Nature MegaKit](https://quaternius.itch.io/stylized-nature-megakit) (Standard) | Quaternius | CC0 1.0 (textures recoloured through our ramps) |
| `SRC_palm_old/curve/young` | [opengameart.org/content/exotic-palms-lowpoly-style](https://opengameart.org/content/exotic-palms-lowpoly-style) | FabinhoSC | CC0 |
| Headland terrain detail | USGS 3D Elevation Program DEM (Nā Pali coast) | U.S. Geological Survey | US public domain |

## Credit lines shown in the game (Settings → Credits)

- "Jellyfish", "Starfish", "Seashell" and "Sea anemone" by Poly by Google (poly.pizza), CC-BY 3.0
- "seashell" by Dario Demi (D911C) (poly.pizza), CC-BY 3.0
- "Ship wheel" by Hero.Craft (sketchfab.com), CC-BY 4.0
- Beach props, palms, rocks, boats and plants from the Pirate Kit and Nature Kit by Kenney (kenney.nl, CC0); sand texture by Rob Tuytel (Poly Haven, CC0)
- Runner ("Beach Character" with its animations), Anchor, Chest, palm and nature kit by Quaternius (CC0); Cannon by James Ray Cock and Yann Kervran, cliffs by Rob Tuytel and Rico Cilliers (Poly Haven, CC0); palms by FabinhoSC (OpenGameArt, CC0)
- Three.js (MIT) · MediaPipe Tasks Vision (Apache-2.0)

## Trademarks

The game uses maroon `#500000` and white as colours only. It contains no Texas A&M logos or wordmarks.
